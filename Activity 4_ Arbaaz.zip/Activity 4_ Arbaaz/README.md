# Calculator Test Automation using Selenium IDE and Mocha

This project automates basic arithmetic operations (Addition, Subtraction, Multiplication, and Division) on a sample calculator web app using Selenium WebDriver and Mocha.

## 🔗 Application Under Test

[UMassD Calculator App](https://umassdgithub.github.io/calculator/)

## 📁 Project Structure

```
calculator-tests/
│
├── test/                      # Selenium-generated Mocha test cases
│   ├── addition.test.js
│   ├── subtraction.test.js
│   ├── multiplication.test.js
│   └── division.test.js
│
├── mochawesome-report/        # Screenshots and test report output will be stored here
│   ├── addition.jpg
│   ├── subtraction.jpg
│   ├── multiplication.jpg
│   └── division.jpg
│
├── package.json               # NPM config with dependencies and test script
└── README.md                  # Setup and usage instructions
```

## 🛠️ Setup Instructions

### 1. Install Node.js (if not installed)
Download and install from: [https://nodejs.org](https://nodejs.org)

### 2. Install Dependencies

Open terminal/command prompt in the project folder and run:

```bash
npm install
```

### 3. Run the Tests

```bash
npm test
```

This will:
- Open Chrome
- Perform addition, subtraction, multiplication, and division
- Take `.jpg` screenshots
- Generate a Mochawesome HTML report

### 4. View Test Report

Open the file:
```
mochawesome-report/mochawesome.html
```

## 📝 Notes

- Make sure Chrome is installed.
- The screenshots will be saved in `.jpg` format in the `mochawesome-report` folder.
- The HTML report will show all test results with success/failure.

---

Created by: Ranjitha Suresh ✨