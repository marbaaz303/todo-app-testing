const {Builder, By, until} = require('selenium-webdriver');
const assert = require('assert');

describe('Division Test', function() {
  this.timeout(30000);
  let driver;

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  afterEach(async () => {
    await driver.quit();
  });

  it('should divide 9 by 3 to get 3', async () => {
    await driver.get("https://umassdgithub.github.io/calculator/");
    await driver.findElement(By.id("btn9")).click();
    await driver.findElement(By.id("btndiv")).click();
    await driver.findElement(By.id("btn3")).click();
    await driver.findElement(By.id("btnequal")).click();
    let result = await driver.findElement(By.id("display")).getAttribute("value");
    assert.strictEqual(result, "3");

    let image = await driver.takeScreenshot();
    require('fs').writeFileSync('mochawesome-report/division.jpg', Buffer.from(image, 'base64'));

  });
});