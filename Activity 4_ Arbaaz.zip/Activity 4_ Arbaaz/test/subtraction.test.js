const {Builder, By, until} = require('selenium-webdriver');
const assert = require('assert');

describe('Subtraction Test', function() {
  this.timeout(30000);
  let driver;

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  afterEach(async () => {
    await driver.quit();
  });

  it('should subtract 5 from 8 to get 3', async () => {
    await driver.get("https://umassdgithub.github.io/calculator/");
    await driver.findElement(By.id("btn8")).click();
    await driver.findElement(By.id("btnminus")).click();
    await driver.findElement(By.id("btn5")).click();
    await driver.findElement(By.id("btnequal")).click();
    let result = await driver.findElement(By.id("display")).getAttribute("value");
    assert.strictEqual(result, "3");

    let image = await driver.takeScreenshot();
    require('fs').writeFileSync('mochawesome-report/subtraction.jpg', Buffer.from(image, 'base64'));

  });
});