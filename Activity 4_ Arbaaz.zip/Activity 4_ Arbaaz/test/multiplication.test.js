const {Builder, By, until} = require('selenium-webdriver');
const assert = require('assert');

describe('Multiplication Test', function() {
  this.timeout(30000);
  let driver;

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  afterEach(async () => {
    await driver.quit();
  });

  it('should multiply 4 by 6 to get 24', async () => {
    await driver.get("https://umassdgithub.github.io/calculator/");
    await driver.findElement(By.id("btn4")).click();
    await driver.findElement(By.id("btnmul")).click();
    await driver.findElement(By.id("btn6")).click();
    await driver.findElement(By.id("btnequal")).click();
    let result = await driver.findElement(By.id("display")).getAttribute("value");
    assert.strictEqual(result, "24");

    let image = await driver.takeScreenshot();
    require('fs').writeFileSync('mochawesome-report/multiplication.jpg', Buffer.from(image, 'base64'));

  });
});