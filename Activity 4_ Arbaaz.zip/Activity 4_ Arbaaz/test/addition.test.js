const {Builder, By, until} = require('selenium-webdriver');
const assert = require('assert');

describe('Addition Test', function() {
  this.timeout(30000);
  let driver;

  beforeEach(async () => {
    driver = await new Builder().forBrowser('chrome').build();
  });

  afterEach(async () => {
    await driver.quit();
  });

  it('should add 7 and 3 to get 10', async () => {
    await driver.get("https://umassdgithub.github.io/calculator/");
    await driver.findElement(By.id("btn7")).click();
    await driver.findElement(By.id("btnplus")).click();
    await driver.findElement(By.id("btn3")).click();
    await driver.findElement(By.id("btnequal")).click();
    let result = await driver.findElement(By.id("display")).getAttribute("value");
    assert.strictEqual(result, "10");

    let image = await driver.takeScreenshot();
    require('fs').writeFileSync('mochawesome-report/addition.jpg', Buffer.from(image, 'base64'));

  });
});