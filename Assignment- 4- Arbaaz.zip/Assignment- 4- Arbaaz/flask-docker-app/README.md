# Flask Docker App

A simple Flask application containerized with Docker.

## Steps to Run

1. Build the Docker image:
    docker build -t flask-docker .

2. Run the Docker container:
    docker run -p 5000:5000 flask-docker

Visit http://localhost:5000 to view the app.
